package edu.nju.expressMgmtSys.model;

import java.io.Serializable;

public enum ExpressType implements Serializable{

    ECONOMY,

    STANDARD,

    EXPRESS;
}
