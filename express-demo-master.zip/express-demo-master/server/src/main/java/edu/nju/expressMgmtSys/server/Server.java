package edu.nju.expressMgmtSys.server;

public class Server {

    public static void main(String[] args) {
        RMIHelper.init();
        System.out.println("Server started!");
    }
}
